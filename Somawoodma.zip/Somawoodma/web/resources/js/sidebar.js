const sidebar = document.querySelector(".sidebar");
const sidebarLockBtn = document.querySelector("#lock-icon");

const toggleLock = () => {
    sidebar.classList.toggle("locked");

    if (!sidebar.classList.contains("locked")) {
        sidebar.classList.add("hoverable");
        sidebarLockBtn.classList.replace("bx-lock-alt", "bx-lock-open-alt");
    } else {
        sidebar.classList.remove("hoverable");
        sidebarLockBtn.classList.replace("bx-lock-open-alt", "bx-lock-alt");
    }
};

const hideSidebar = () => {
    if (sidebar.classList.contains("hoverable")) {
        sidebar.classList.add("close");
    }
};

const showSidebar = () => {
    if (sidebar.classList.contains("hoverable")) {
        sidebar.classList.remove("close");
    }
};

const toggleSidebar = () => {
    sidebar.classList.toggle("close");
};

if (window.innerWidth < 800) {
    sidebar.classList.add("close");
    sidebar.classList.remove("locked");
    sidebar.classList.remove("hoverable");
}

sidebarLockBtn.addEventListener("click", toggleLock);
sidebar.addEventListener("mouseleave", hideSidebar);
sidebar.addEventListener("mouseenter", showSidebar);

const $tiempo = document.querySelector('.tiempo');
const $fecha = document.querySelector('.fecha');

function RelojDigital() { // Corregido a RelojDigital con 'D' mayúscula
    let f = new Date(),
        dia = ('0' + f.getDate()).slice(-2),
        mes = ('0' + (f.getMonth() + 1)).slice(-2),
        anio = f.getFullYear(),
        diaSemana = f.getDay();

    const timeString = f.toLocaleTimeString();
    $tiempo.innerHTML = timeString;

    const semana = ['DOMINGO', 'LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SÁBADO'];
    $fecha.innerHTML = `${semana[diaSemana]} ${dia}-${mes}-${anio}`;
}

setInterval(RelojDigital, 1000); // Corregido a RelojDigital con 'D' mayúscula
